package com.example.businessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioGroup radioGroupSelectCar;
    CheckBox firstTimeCheck;
    RadioButton selectedCar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioGroupSelectCar=findViewById(R.id.radioGroupSelectCar);
        firstTimeCheck=findViewById(R.id.firstTimeCheck);


    }
    public void checkButton(View view){

        Intent newCustomer = new Intent(this, activity3.class);
        Intent member = new Intent(this, activity2.class);

            //Toast.makeText(this,"Select a car ", Toast.LENGTH_SHORT).show();

            int carSelected = radioGroupSelectCar.getCheckedRadioButtonId();
            selectedCar = findViewById(carSelected);
            Toast.makeText(this,"Selected "+ selectedCar.getText(), Toast.LENGTH_SHORT).show();
            if (firstTimeCheck.isChecked()) {
                newCustomer.putExtra("carSelected", carSelected);
                startActivity(newCustomer);
            } else if(firstTimeCheck.isChecked()==false) {
                member.putExtra("carSelected", carSelected);
                startActivity(member);
            }




        }
    }

