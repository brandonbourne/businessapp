package com.example.businessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class activity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity4);

        //display the car selected with the cost associated with it and ask user the duration.
    }
}
