package com.example.businessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class activity3 extends AppCompatActivity {
    EditText signInEmail;
    EditText createPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity3);

        signInEmail = findViewById(R.id.signUpEmail);
        createPassword = findViewById(R.id.createPassword);


    }
    public void signUpBtnClick(View view){

        Intent signUp = new Intent(this, activity4.class);


            String email = signInEmail.getText().toString();
            String password = createPassword.getText().toString();
            signUp.putExtra("email",email);
            signUp.putExtra("password",password);

            startActivity(signUp);

            Toast.makeText(this, "Please create an Email and Password",Toast.LENGTH_SHORT).show();

    }
}
