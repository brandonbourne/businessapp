package com.example.businessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class activity2 extends AppCompatActivity {
    EditText email;
    EditText password;
    Button signInBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity2);

        email = findViewById(R.id.signUpEmail);
        password = findViewById(R.id.password);
        signInBtn = findViewById(R.id.signInBtn);

    }

    public void submitClick(View view) {
        Intent signIn = new Intent(this, activity4.class);


            String passwordInput = password.getText().toString();
            String emailInput = email.getText().toString();
            signIn.putExtra("emailInput", emailInput);
            signIn.putExtra("passwordInput", passwordInput);
            startActivity(signIn);

            Toast.makeText(this, "Enter an email and password", Toast.LENGTH_SHORT).show();

        }
    }
